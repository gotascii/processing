SPHEROID :: source

GENERAL INSTRUCTIONS:
� Put the 'spheroid' folder into your projects folder for Processing (version 91+).
� For this sketch to work properly, you will need to have a webcam that Processing can access.
� Open up Processing and load the sketch.


CONTROLS:
� UP and DOWN arrows control the distance of the objects from the center point.
� RIGHT and LEFT arrows adjust the rotation offset.
� SPACE toggles the background image.
� Q,W,E,R,T,Y,U,and I are preset positions and rotations.
� Camera can be controlled with the number pad.
  7 zooms in
  1 zooms out
  8 and 2 adjust elevation
  4 and 6 adjust azimuth
  5 stops rotation


July 11, 2005

Robert Hodgin
flight404.com
robert [at] flight404 {dot} com


